// Zheen Suseyi
// 05/23/2023
// CS 320
// SNHU
package contactProject;

public class Contact {
    private String id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;

    // Contact Constructor with all parameters
	public Contact(String id, String firstName, String lastName, String phoneNumber, String address){
        // Check if id length exceeds 10 characters
  
    	if (id == null) {
            throw new NullPointerException("ID is required and cannot be null.");
        }
    	if (id.length() > 10) {
             throw new IllegalArgumentException("Full name cannot have more than 20 characters.");
        }
    	
    	if (firstName == null) {
            throw new NullPointerException("first name is required and cannot be null.");
        }
        if (firstName.length() > 10) {
            throw new IllegalArgumentException("Full name cannot have more than 20 characters.");
        }
        
        if (lastName == null) {
            throw new NullPointerException("Description is required and cannot be null.");
        }
        if (lastName.length() > 10) {
            throw new IllegalArgumentException("last Name cannot be longer than 10 characters.");
        }
       
        if (phoneNumber == null) {
            throw new NullPointerException("Phone number is required and cannot be null.");
        }
        if (phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits");
        }
       
        if (address == null) {
            throw new NullPointerException("Address is required and cannot be null.");
        }
        if (address.length() > 30) {
            throw new IllegalArgumentException("Address must be no longer then 30 characters");
        }
        
        
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Default Contact Constructor
    public Contact() {
    }

    // Getter for id
    public String getContactID(){
        return id;
    }

    // Getter for firstName
    public String getFirstName() {
        return firstName;
    }
    
    // Getter for lastName
    public String getLastName() {
        return lastName;
    }
    
    // Getter for phoneNumber
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    // Getter  for address
    public String getAddress() {
        return address;
    }

    // Setter for firstName
    public void setFirstName(String firstName) {
        // Check if firstName is null
        if (firstName == null) {
            throw new IllegalArgumentException("First name is required and cannot be null.");
        }
        // Check if firstName length exceeds 10 characters
        if (firstName.length()>10){
            throw new IllegalArgumentException("First name cannot be longer than 10 characters.");
        }
        this.firstName = firstName;
    }

   
// Setter for lastName
    public void setLastName(String lastName) {
        // Check if lastName is null
        if (lastName == null) {
            throw new IllegalArgumentException("Last name is required and cannot be null.");
        }
        // Check if lastName length exceeds 10 characters
        if (lastName.length()>10){
            throw new IllegalArgumentException("Last name cannot be longer than 10 characters.");
        }
        this.lastName = lastName;
    }

   
// Setter for phoneNumber
    public void setPhoneNumber(String phoneNumber) {
        // Check if phoneNumber is null
        if (phoneNumber == null) {
            throw new IllegalArgumentException("Phone number is required and cannot be null.");
        }
        // Check if phoneNumber length is not 10 characters
        if (phoneNumber.length()!=10){
            throw new IllegalArgumentException("Phone number must be 10 characters long.");
        }
        this.phoneNumber = phoneNumber;
    }  

// Setter for address
    public void setAddress(String address) {
        // Check if address is null
        if (address == null) {
            throw new IllegalArgumentException("Address is required and cannot be null.");
        }
        // Check if address length exceeds 30 characters
        if (address.length()>30){
            throw new IllegalArgumentException("Address cannot be longer than 10 characters.");
        }
        this.address = address;
    }
}
