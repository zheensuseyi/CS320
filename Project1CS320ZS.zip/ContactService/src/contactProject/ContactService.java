package contactProject;

import java.util.ArrayList;

public class ContactService {
    // ArrayList to store contacts
	public static ArrayList<Contact> contactList = new ArrayList<>();

    // Method to add a new contact with a given contact object
    public static void addContact(Contact newContact) {
        // Adding the new task to the taskList
    	for(int i = 0; i < contactList.size(); i++) {
    		if(contactList.get(i).getContactID() == newContact.getContactID()) {
    			throw new IllegalArgumentException("Each ID Must be unique");
    		}
    	}
    	contactList.add(newContact);
    }

    // Method to delete a contact based on its id
    public static String deleteContact(String id) {
        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContactID() == id) {
                // Remove the contact from contactList
            	contactList.remove(contactList.get(i));
                return ("Contact with id " + id + " removed.");
            }
        }
        return ("No contact with id " + id + " found.");
    }
    
    // Method to update a task based on its id
    public static String updateContact(String id, String firstName, String lastName, String phoneNumber, String address) {
        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContactID() == id) {
                // Retrieve the contact from contactList
                Contact contact = contactList.get(i);
                // Update the contact's information
                contact.setFirstName(firstName);
                contact.setLastName(lastName);
                contact.setPhoneNumber(phoneNumber);
                contact.setAddress(address);
                return ("Contact updated.");
            }
        }
        return ("No contact with id " + id + " found.");
    }
    
    // Getting any contact by its ID  
    public static Contact getContactById(String id) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(id)) {
                return contact;
            }
        }
        return null; // Contact with the given ID not found
    }  
}

