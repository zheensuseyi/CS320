package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactProject.Contact;

class ContactTest {
		
		// Test to see if Junit is working
	 	@Test
	    void testContact() {
	        Contact contact = new Contact("12345", "John", "Smith", "8582546895", "5362 yorkshire dr");
	        assertEquals("12345", contact.getContactID());
	        assertEquals("John", contact.getFirstName());
	        assertEquals("Smith", contact.getLastName());
	        assertEquals("8582546895", contact.getPhoneNumber());
	        assertEquals("5362 yorkshire dr", contact.getAddress());
	    }

	 	// Test for ID too long
	    @Test
	    void testIDTooLong() {
	        Assertions.assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("999999999999999999999999999999999999999999", "John", "Smith", "8582546895", "5362 yorkshire dr");
	        });
	    }
	   
	    // Test for ID null
	    @Test
	    void testIDnull() {
	        Assertions.assertThrows(NullPointerException.class, () -> {
	            new Contact(null, "John", "Smith", "8582546895", "5362 yorkshire dr");
	        });
	    }
	    
	 	// Test for first name too long
	    @Test
	    void testFirstNameTooLong() {
	        Assertions.assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "66666666666666666666666666666666666666666666666666666666", "Smith", "8582546895", "5362 yorkshire dr");
	        });
	    }
	 	
	    // Test for first name null
	    @Test
	    void testFirstNameNull() {
	        Assertions.assertThrows(NullPointerException.class, () -> {
	            new Contact("12345", null, "Smith", "8582546895", "5362 yorkshire dr");
	        });          
	    }
	    
	    // Test for last name too long
	    @Test
	    void testLastNameTooLong() {
	        Assertions.assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "John", "Smithhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh", "8582546895", "5362 yorkshire dr");
	        });          
	    }
	    
	    // Test for last name null
	    @Test
	    void testLastNameNull() {
	        Assertions.assertThrows(NullPointerException.class, () -> {
	            new Contact("12345", "John", null, "8582546895", "5362 yorkshire dr");
	        });          
	    }
	    
	    // Test for phone number too long
	    @Test
	    void testPhoneNumberNotTen() {
	        Assertions.assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "John", "Smith", "858254689555555", "5362 yorkshire dr");
	        });          
	    }
	    
	    // Test for phone number null
	    void testPhoneNumberNull() {
	        Assertions.assertThrows(NullPointerException.class, () -> {
	            new Contact("12345", "John", "Smith", null, "5362 yorkshire dr");
	        });          
	    }
	    
	    // Test for address too long
	    void testAddressTooLong() {
	        Assertions.assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "John", "Smith", "8582546895", "5362 yorkshire drrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr");
	        });          
	    }
	    
	    // Test for address null
	    void testAddressNull() {
	        Assertions.assertThrows(NullPointerException.class, () -> {
	            new Contact("12345", "John", "Smith", "8582546895", null);
	        });          
	    }
	}
