package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import contactProject.Contact;
import contactProject.ContactService;

class ContactServiceTest {
	
	// Testing adding contacts with same ID
	@Test
	void testServiceAddContact() {
		Contact contact = new Contact("Nice123", "Bobby", "Smith", "8582546895", "5362 Mouser Dr");
		Contact contact2 = new Contact("Nice123", "Rob", "Wilson", "8582556676", "6222 Duck Ave");
		ContactService.addContact(contact);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		     ContactService.addContact(contact2); 
		     });
       	}
	
	// Testing delete contact
	@Test
	void testServiceDeleteTask() {
		 Contact contact = new Contact("Nice124", "Bobby", "Smith", "8582546895", "5362 Mouser Dr");
	        ContactService.addContact(contact);

	        ContactService.deleteContact("Nice124");
	        
	        Assertions.assertNull(ContactService.getContactById("Nice124"));
        	};
    
    // Testing updating contact
	@Test
	void testServiceUpdateTask() {
		 // Creating a contact for this test
        Contact contact = new Contact("Nice125", "Bobby", "Smith", "8582546895", "5362 Mouser Dr");

        // Adding our contact to ContactService
        ContactService.addContact(contact);

        // Making new variables to update our contact
        String newFirstName = "Zheen";
        String newLastName = "Mousy";
        String newPhoneNumber = "8582553211";
        String newAddress = "7367 Mallard DR";
        // Updating our contact we created
        String result = ContactService.updateContact("Nice125", "Zheen", "Mousy", "8582553211", "7367 Mallard DR");

        // Seeing if the contact updated correctly
        assertEquals("Contact updated.", result);
        Contact newContact = ContactService.getContactById("Nice125");
        assertEquals(newFirstName, newContact.getFirstName());
        assertEquals(newLastName, newContact.getLastName());
        assertEquals(newPhoneNumber, newContact.getPhoneNumber());
        assertEquals(newAddress, newContact.getAddress());
	}
}
