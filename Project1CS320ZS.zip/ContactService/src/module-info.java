module contactProject {
	requires org.junit.jupiter.api;
}