package test;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;

class AppointmentServiceTest {
	// Setting variables for date testing
	Date date1 = new Date(System.currentTimeMillis() + 5000000);
	Date date2 = new Date(System.currentTimeMillis() + 5000055);

	// Testing add appointment
	@Test
	void testServiceAddAppointment() {
		Appointment appointment = new Appointment("Nice123", date1, "Here for a routine checkup");
		Appointment appointment2 = new Appointment("Nice123", date2, "Emergency Surgery");
		AppointmentService.addAppointment(appointment);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			AppointmentService.addAppointment(appointment2); 
		     });
       	}
	
	// Testing delete appointment
	@Test
	void testServiceDeleteAppointment() {
		Appointment appointment3 = new Appointment("Nice125", date1, "Here for a routine checkup");
		 AppointmentService.addAppointment(appointment3);
		 AppointmentService.deleteAppointment("Nice125");   
	        Assertions.assertNull(AppointmentService.getAppointmentById("Nice125"));
        	};

}
