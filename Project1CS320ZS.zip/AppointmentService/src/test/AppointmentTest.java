package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;
import appointmentService.Appointment;

class AppointmentTest {
	// Setting variables for date testing
	Date date = new Date(System.currentTimeMillis());
	Date appointmentDate = new Date(System.currentTimeMillis() + 500000);
	Date pastDate = new Date(System.currentTimeMillis() - 500000);
	
	// Testing if junit is working
	@Test
    void testAppointment() {
    	Appointment appointment = new Appointment("12345", appointmentDate, "New appointment for monday");
        assertEquals("12345", appointment.getID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals("New appointment for monday", appointment.getDescription());
    }

	// Testing ID length
    @Test
    void testIDTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123455555555555555555555555555555555", appointmentDate, "John works in IT");
        });
    }
   
    // Testing ID null
    @Test
    void testIDnull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
                new Appointment(null, appointmentDate, "John works in IT");
            });
    }
    
    // Testing if date is in the past
    @Test
    void testDateInPast() {
    	assertTrue(pastDate.before(date));
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "John works in IT");
        });
    }
    
    // Testing date null
    @Test
    void testDatenull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
            new Appointment("12345", null, "John works in IT");
        });          
    }

    // Testing Description length
    @Test
    void testDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", appointmentDate, "John works in ITTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");
        });          
    }
    
    // Testing Description null
    @Test
    void testDescriptionnull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
            new Appointment("12345", appointmentDate, null);
        });          
    }
}


