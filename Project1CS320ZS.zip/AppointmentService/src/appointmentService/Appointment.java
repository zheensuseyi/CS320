// Zheen Suseyi
// 06/04/2023
// CS 320
// SNHU

package appointmentService;
import java.util.Date;


	public class Appointment {
	    private String ID;
	    private java.util.Date appointmentDate;
	    private String Description;

	    // Appointment Constructor with all parameters
		public Appointment(String ID, Date appointmentDate, String Description){
	        // Check if id is null
	    	if (ID == null) {
	            throw new NullPointerException("ID is required and cannot be null.");
	        }
	        // Check if id length exceeds 10 characters
	    	if (ID.length() > 10) {
	             throw new IllegalArgumentException("ID cannot have more than 10 characters.");
	        }
	        // Check if appointment is null
	    	if (appointmentDate == null) {
	            throw new NullPointerException("Date is required and cannot be null.");
	        }
	    	// Check if appointment date is in the present
	    	Date date = new Date(System.currentTimeMillis());
	        if(appointmentDate.before(date)) {
	            throw new IllegalArgumentException("Date is in the past and invalid");
	        }
	        
	        // Checking if description is null
	    	if (Description == null) {
	            throw new NullPointerException("Description is required and cannot be null.");
	        }
	        // Checking if description length greater then 50

	        if (Description.length() > 50) {
	            throw new IllegalArgumentException("Description cannot have more than 50 characters.");
	        }
	        
	        this.ID = ID;
	        this.appointmentDate = appointmentDate;
	        this.Description = Description;

	    }

	    // Default Appointment Constructor
	    public Appointment() {
	    }

	    // Getter for ID
	    public String getID(){
	        return ID;
	    }

	    // Getter for Date
	    public Date getAppointmentDate() {
	        return appointmentDate;
	    }
	    // Getter for desciption
	    public String getDescription() {
	        return Description;
	    }
	    
	    // Setter for ID
	    public void setID(String ID) {
	        // Check if firstName is null
	        if (ID == null) {
	            throw new IllegalArgumentException("ID is required and cannot be null.");
	        }
	        // Check if firstName length exceeds 10 characters
	        if (ID.length()>10){
	            throw new IllegalArgumentException("ID cannot be longer than 10 characters.");
	        }
	        this.ID = ID;
	    }
	    // Setter for appointmentDate
	    public void setAppointmentDate(Date appointmentDate) {
	        // Check if appointmentDate is null
	        if (appointmentDate == null) {
	            throw new IllegalArgumentException("First name is required and cannot be null.");
	        }
	        // Check if date is in the past
	        Date date = new Date(System.currentTimeMillis());
	        if(appointmentDate.before(date)) {
	            throw new IllegalArgumentException("Date is in the past and invalid");
	        }
	        this.appointmentDate = appointmentDate;
	    }  
	    // Setter for description
	    public void setDescription(String Description) {
	        // Check if Description is null
	        if (Description == null) {
	            throw new IllegalArgumentException("Description is required and cannot be null.");
	        }
	        // Check if Description length exceeds 50 characters
	        if (Description.length()>50){
	            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
	        }
	        this.Description = Description;
	    }
}


