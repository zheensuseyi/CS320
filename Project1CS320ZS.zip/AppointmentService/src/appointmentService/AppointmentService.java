package appointmentService;
import java.util.ArrayList;

public class AppointmentService {

		public static ArrayList<Appointment> appointmentList = new ArrayList<>();

	    // Method to add a new appointment with a given appointment object
	    public static void addAppointment(Appointment newAppointment) {
	        // Adding the new appointment to the appointmentList
	    	for(int i = 0; i < appointmentList.size(); i++) {
	    		if(appointmentList.get(i).getID() == newAppointment.getID()) {
	    			throw new IllegalArgumentException("Each ID Must be unique");
	    		}
	    	}
	    	appointmentList.add(newAppointment);
	    }

	    // Method to delete a Appointment based on its id
	    public static String deleteAppointment(String id) {
	        for (int i = 0; i < appointmentList.size(); i++) {
	            if (appointmentList.get(i).getID() == id) {
	                // Remove the contact from contactList
	            	appointmentList.remove(appointmentList.get(i));
	                return ("Appointment with id " + id + " removed.");
	            }
	        }
	        return ("No Appointment with id " + id + " found.");
	    }
	    
	    
	    // Getting any Appointment by its ID  
	    public static Appointment getAppointmentById(String ID) {
	        for (Appointment appointment : appointmentList) {
	            if (appointment.getID().equals(ID)) {
	                return appointment;
	            }
	        }
	        return null; // Appointment with the given ID not found
	    }  
	}

