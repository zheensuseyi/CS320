package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import taskService.Task;
import taskService.TaskService;

class TastServiceTest {
	
	// Testing adding a tasks with same ID
	@Test
	void testServiceAddTask() {
		Task task = new Task("Nice123", "Bobby Smith", "Hey this is Bobby");
		Task task2 = new Task("Nice123", "John Wilson", "Hey this is John");
		TaskService.addTask(task);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		     TaskService.addTask(task2); 
		     });
       	}
	
	// Testing delete task
	@Test
	void testServiceDeleteTask() {
		 Task task = new Task("Nice124", "Bobby Smith", "Hey this is Bobby");
	        TaskService.addTask(task);

	        TaskService.deleteTask("Nice124");
	        
	        Assertions.assertNull(TaskService.getTaskById("Nice124"));
        	};
    
    // Testing updating task
	@Test
	void testServiceUpdateTask() {
		 // Creating a task for this test
        Task task = new Task("Nice125", "Bobby Smith", "Hey this is Bobby");

        // Adding our task to TaskService
        TaskService.addTask(task);

        // Making new variables to update our task
        String newName = "Zheen McGreen";
        String newDescription = "Zheen is the new CEO";
        // Updating our task we created
        String result = TaskService.updateTask("Nice125", newName, newDescription);

        // Seeing if the task updated correctly
        assertEquals("Contact updated.", result);
        Task newTask = TaskService.getTaskById("Nice125");
        assertEquals(newName, newTask.getfullName());
        assertEquals(newDescription, newTask.getfullDescription());
	}
}
