package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.Task;

class TaskTest {

	// Testing to see if junit works
    @Test
    void testTask() {
        Task task = new Task("12345", "John Smith", "John works in IT");
        assertEquals("12345", task.getTaskID());
        assertEquals("John Smith", task.getfullName());
        assertEquals("John works in IT", task.getfullDescription());
    }

    // Testing taskID length
    @Test
    void testTaskIDTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123455555555555555555555555555555555", "John Smith", "John works in IT");
        });
    }
   
    // Testing taskID null
    @Test
    void testTaskIDnull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
                new Task(null, "John Smith", "John works in IT");
            });
    }
    
    // Testing fullName length
    @Test
    void testfullNameTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "John SmithHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH", "John works in IT");
        });
    }
    
    // Testing fullName null
    @Test
    void testfullNamenull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
            new Task("12345", null, "John works in IT");
        });          
    }

    // Testing fullDescription length
    @Test
    void testfullDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "John Smith", "John works in ITTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");
        });          
    }
    
    // Testing fullDescription null
    @Test
    void testfullDescriptionnull() {
        Assertions.assertThrows(NullPointerException.class, () -> {
            new Task("12345", "John Smith", null);
        });          
    }
}