module taskService {
	requires org.junit.jupiter.api;
}