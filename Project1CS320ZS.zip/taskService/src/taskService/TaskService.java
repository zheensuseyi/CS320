package taskService;

import java.util.ArrayList;

public class TaskService {
	// Making our arraylist to store our tasks
	 public static ArrayList<Task> taskList = new ArrayList<>();

	    // Method to add a new task with a given task object
	    public static void addTask(Task newTask) {
	        // Adding the new task to the taskList
	    	for(int i = 0; i < taskList.size(); i++) {
	    		if(taskList.get(i).getTaskID() == newTask.getTaskID()) {
	    			throw new IllegalArgumentException("Each ID Must be unique");
	    		}
	    	}
	    	taskList.add(newTask);
	    }

	    // Method to delete a task based on its id
	    public static String deleteTask(String taskID) {
	        for (int i = 0; i < taskList.size(); i++) {
	            if (taskList.get(i).getTaskID() == taskID) {
	                // Remove the contact from contactList
	            	taskList.remove(taskList.get(i));
	                return ("Contact with id " + taskID + " removed.");
	            }
	        }
	        return ("No contact with id " + taskID + " found.");
	    }
	    
	    // Method to update a task based on its id
	    public static String updateTask(String taskID, String fullName, String fullDescription) {
	        for (int i = 0; i < taskList.size(); i++) {
	            if (taskList.get(i).getTaskID() == taskID) {
	                // Retrieve the contact from contactList
	                Task task = taskList.get(i);
	                // Update the contact's information
	                task.setfullName(fullName);
	                task.setfullDescription(fullDescription);
	                return ("Contact updated.");
	            }
	        }
	        return ("No contact with id " + taskID + " found.");
	    }
	    
	    // Getting any task by its ID  
	    public static Task getTaskById(String taskId) {
	        for (Task task : taskList) {
	            if (task.getTaskID().equals(taskId)) {
	                return task;
	            }
	        }
	        return null; // Task with the given ID not found
	    }  
}
