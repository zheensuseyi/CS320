// Zheen Suseyi
// 05/27/2023
// CS 320
// SNHU

package taskService;

public class Task {
	// Defining our variables
    private String taskID;
    private String fullName;
    private String fullDescription;
    // Task Object Creation
    public Task(String taskID, String fullName, String fullDescription) {
    	// Doing our arguments for taskID, fullName, fullDescription
    	if (taskID == null) {
             throw new NullPointerException("ID is required and cannot be null.");
         }
        if (taskID.length() > 10) {
            throw new IllegalArgumentException("ID cannot have more than 10 characters.");
        }
       
        if (fullName == null) {
            throw new NullPointerException("Full name is required and cannot be null.");
        }
        if (fullName.length() > 20) {
            throw new IllegalArgumentException("Full name cannot have more than 20 characters.");
        }
        if (fullDescription == null) {
            throw new NullPointerException("Description is required and cannot be null.");
        }
        if (fullDescription.length() > 50) {
            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
        }
       
        this.taskID = taskID;
        this.fullName = fullName;
        this.fullDescription = fullDescription;
    }
   
    // Default Constructor 
    public Task() {
    }
    
    // Getters 
    public String getTaskID() {
        return taskID;
    }

    public String getfullName() {
        return fullName;
    }

    public String getfullDescription() {
        return fullDescription;
    }

    // Setters
    public void settaskID(String taskID) {
        // Checking for null id
        if (taskID == null) {
            throw new NullPointerException("ID is required and cannot be null.");
        }
        // Checking if id is greater then 10 characters
        if (taskID.length() > 10) {
            throw new IllegalArgumentException("ID cannot have more than 10 characters.");
        }
        this.taskID = taskID;
    }

    public void setfullName(String fullName) {
        // Checking for null fullName
        if (fullName == null) {
            throw new NullPointerException("Full name is required and cannot be null.");
        }
        // Checking for character length > 20 characters
        if (fullName.length() > 20) {
            throw new IllegalArgumentException("Full name cannot have more than 20 characters.");
        }
        this.fullName = fullName;
    }
    
    public void setfullDescription(String fullDescription) {
        // Checking for null fullDescription
        if (fullDescription == null) {
            throw new NullPointerException("Description is required and cannot be null.");
        }
        // Checking for fullDescription length > 50 characters
        if (fullDescription.length() > 50) {
            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
        }
        this.fullDescription = fullDescription;
    }
}
